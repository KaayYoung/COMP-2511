package search;

public interface Heuristic {
	public int calculateHValue(AStarNode current);
}
