package Controller.Search;

import java.util.List;

import Controller.Board;

public interface SearchAlgorithm {
	public enum Mode {
		PRINT_BOARD,
		PRINT_CARS
	}
	List <Board> getPath(Board board, boolean debug);
	
	public void printSolution(List<Board> shortestSolution, Mode mode);
}
