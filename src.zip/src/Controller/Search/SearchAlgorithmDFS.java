package Controller.Search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import Controller.Board;

public class SearchAlgorithmDFS implements SearchAlgorithm {

	public List<Board> getPath(Board board, boolean debug) {
		Board frontBoard = new Board(board.getCars());
		ArrayList<Board> frontPath = new ArrayList<Board>();
		
		ArrayList<Board> discovered = new ArrayList<Board>();
		List<List<Board>> solutions = new ArrayList<List<Board>>();
		ArrayList<Board> moves = new ArrayList<Board>();
		
		Queue<Board> boardQueue = new LinkedList<Board>();
		boardQueue.add(frontBoard);
		
		Queue<ArrayList<Board>> pathQueue = new LinkedList<ArrayList<Board>>();
		ArrayList<Board> newPath = new ArrayList<Board>();
		
		Map<Integer, Integer> depthStates = new HashMap<Integer, Integer>();
		
		// Find all solutions
		while (boardQueue.size() != 0) {
			frontBoard = boardQueue.poll();
			
			if (pathQueue.size() != 0) {
				frontPath = new ArrayList<Board>(pathQueue.poll());
			}

			frontPath.add(frontBoard);
			newPath = frontPath;
			
			if (debug) {
				// Count depth for debug
				if (!depthStates.containsKey(newPath.size())) depthStates.put(newPath.size(), 1);
				else depthStates.put(newPath.size(), depthStates.get(newPath.size()) + 1);
			}
			
			if (discovered.contains(frontBoard)) {
				continue;
			}
			else {
				discovered.add(frontBoard);
			}
			
			if (frontBoard.isSolved()) {
				solutions.add(newPath);
			}
			else {
				moves = frontBoard.getPossibleMoves();
				for (Board b : moves) {
					boardQueue.add(b);
					pathQueue.add(newPath);
				}
			}
		}
		
		
		
		// Get shortest solution
		List<Board> shortestSolution = new ArrayList<Board>();
		if (solutions.size() != 0) {
			shortestSolution = solutions.get(0);
			for (int i = 1; i < solutions.size(); i++) {
				if (solutions.get(i).size() < shortestSolution.size()) {
					shortestSolution = solutions.get(i);
				}
			}
		}
		
		if (debug) {
			// Count nodes in memory for debug
			int maxNodes = 0;
			for (int i = 0; i < depthStates.size(); i++) {
				if (depthStates.get(i) != null) {
					maxNodes += depthStates.get(i);
				}
			}
			
			// Count cycle in solutions for debug
			int cycleCount = 0;
			for (int i = 0; i < solutions.size(); i++) {
				for (int j = 0; j < solutions.size(); j++) {
					if (i != j && solutions.get(i).get(solutions.get(i).size() - 1) == solutions.get(j).get(solutions.get(j).size() - 1)) {
						cycleCount++;
					}
				}
			}

			System.out.println();
			System.out.println("TOTAL SOLUTIONS: " + solutions.size());
			System.out.println("TOTAL CYCLES: " + cycleCount);
			System.out.println("MOVE # OF THE SHORTEST SOLUTION: " + (shortestSolution.size() - 1));
			System.out.println("TOTAL NODES GENERATED: " + discovered.size());
			System.out.println("MAXIMUM # OF NODES KEPT IN MEMORY: " + maxNodes);
			System.out.println();
		}
		
		return shortestSolution;
	}
	
	// Print steps to solution
	// Mode: 0 - print cars, 1 - print board
	public void printSolution(List<Board> solution, Mode mode) {
		if (mode == Mode.PRINT_CARS) {
			for (int i = 1; i < solution.size(); i++) {
				solution.get(i).printCars();
				System.out.println();
			}
		}
		else if (mode == Mode.PRINT_BOARD) {
			for (int i = 1; i < solution.size(); i++) {
				solution.get(i).printBoard();
				System.out.println();
			}
		}
	}
}
