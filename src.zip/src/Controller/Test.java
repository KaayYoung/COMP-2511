package Controller;

import java.util.HashMap;
import java.util.List;

import Controller.Car.Direction;
import Controller.Search.SearchAlgorithm;
import Controller.Search.SearchAlgorithmDFS;
import Controller.Search.SearchAlgorithm.Mode;

public class Test {
	public static void main(String[] args) {
		// 83-move Configuration
		Car car1 = new Car(1, 2, 3, 2, Direction.HORIZONTAL);
		Car car2 = new Car(2, 2, 2, 3, Direction.VERTICAL);
		Car car3 = new Car(3, 0, 3, 2, Direction.HORIZONTAL);
		Car car4 = new Car(4, 2, 5, 3, Direction.VERTICAL);
		Car car5 = new Car(5, 3, 4, 2, Direction.HORIZONTAL);
		Car car6 = new Car(6, 5, 3, 3, Direction.VERTICAL);
		Car car7 = new Car(7, 5, 4, 2, Direction.HORIZONTAL);
		Car car8 = new Car(8, 5, 0, 2, Direction.VERTICAL);
		Car car9 = new Car(9, 4, 1, 2, Direction.HORIZONTAL);
		
		HashMap<Integer, Car> cars = new HashMap<Integer, Car>();
		
		cars.put(car1.getCarId(), car1);
		cars.put(car2.getCarId(), car2);
		cars.put(car3.getCarId(), car3);
		cars.put(car4.getCarId(), car4);
		cars.put(car5.getCarId(), car5);
		cars.put(car6.getCarId(), car6);
		cars.put(car7.getCarId(), car7);
		cars.put(car8.getCarId(), car8);
		cars.put(car9.getCarId(), car9);
		
		Board gBoard = new Board(cars);
		
		gBoard.printBoard();
		
		SearchAlgorithm search = new SearchAlgorithmDFS();
		
		long startTime = System.currentTimeMillis();
		List<Board> path = search.getPath(gBoard, false);
		long endTime = System.currentTimeMillis();
		long duration = (endTime - startTime);
		
		System.out.println("SOLUTION:");
		search.printSolution(path, Mode.PRINT_BOARD);
		
		System.out.println("TIME: " + duration);
	}

}