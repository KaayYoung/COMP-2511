package View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import javax.swing.border.MatteBorder;

import Controller.Car.Direction;

public class RushHourGrid {

    public static void main(String[] args) {
        new RushHourGrid();
    }

    public RushHourGrid() {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
            	
                try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
               

                JFrame frame = new JFrame("Testing");
                frame.setSize(300, 300);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setLayout(new BorderLayout());
                JPanel testPane = new TestPane();
                JComponent carComponent = new CarComponent();
                frame.add(carComponent);
                frame.add(testPane);
                frame.pack();
                carComponent.repaint();
                
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                
            }
        });
    }

    public class TestPane extends JPanel {

        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public TestPane() {
            setLayout(new GridBagLayout());
            
            GridBagConstraints gbc = new GridBagConstraints();
            for (int row = 0; row < 5; row++) {
                for (int col = 0; col < 5; col++) {
                    gbc.gridx = col;
                    gbc.gridy = row;

                    CellPane cellPane = new CellPane();
                    Border border = null;
                    if (row < 4) {
                        if (col < 4) {
                            border = new MatteBorder(1, 1, 0, 0, Color.GRAY);
                        } else {
                            border = new MatteBorder(1, 1, 0, 1, Color.GRAY);
                        }
                    } else {
                        if (col < 4) {
                            border = new MatteBorder(1, 1, 1, 0, Color.GRAY);
                        } else {
                            border = new MatteBorder(1, 1, 1, 1, Color.GRAY);
                        }
                    }
                    cellPane.setBorder(border);
                    add(cellPane, gbc);
                }
            }
           
        }
    }

    public class CellPane extends JPanel {

        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		public CellPane() {
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    System.out.println("ROW: "+getY()/50+" COL: "+getX()/50);
                }

//                @Override
//                public void mouseExited(MouseEvent e) {
//                    setBackground(defaultBackground);
//                }

	            @Override
	            public void mouseMoved(MouseEvent e) {
	            	System.out.println("X: "+getMousePosition().x+" Y: "+getMousePosition().y);
	            }

            });
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(50, 50);
        }
    }
    
    public class CarComponent extends JComponent {

        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private CarShape car;
		
		public CarComponent() {
			car = new CarShape(0, 0, 3, Direction.HORIZONTAL);
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2 = (Graphics2D) g;
			car.draw(g2);
		}
    }
}