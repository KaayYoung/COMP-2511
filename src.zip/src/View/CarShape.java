package View;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Rectangle2D;

import Controller.Car.Direction;

public class CarShape {
	private int row;
	private int col;
	private Direction direction;
	private int length;
	
	public CarShape(int row, int col, int length, Direction direction) {
		this.row = row;
		this.col = col;
		this.length = length;
		this.direction = direction;
	}
	
	public void draw(Graphics2D g2) {
		Rectangle2D.Double body;
		if (direction == Direction.HORIZONTAL) {
			body = new Rectangle2D.Double(row * 50, col * 50, length * 50, 50);
		}
		else {
			body = new Rectangle2D.Double(row * 50, col * 50, 50, length * 50);
		}
		g2.draw(body);
	}
	
	public boolean contains(Point p) {
		return row * 50 <= p.getX() && p.getX() <= (row + length) * 50 && col * 50 <= p.getY() && p.getY() <= (col + length) * 50;
	}
	
	public void translate(int dx, int dy) {
		row += dx;
		col += dy;
	}
}
